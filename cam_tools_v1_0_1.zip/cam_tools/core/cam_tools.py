
import bpy
import mathutils
import bpy_extras
from bpy.app.handlers import persistent
from bpy.types import Operator, Panel, UIList, PropertyGroup
from bpy.props import IntProperty, PointerProperty, StringProperty, BoolProperty


# ------------------------------------------------------------------------
# Internal state flags (module-level)
# ------------------------------------------------------------------------

_is_syncing_camtools = False

# ------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------

def get_view3d_area_space(context):
    win = context.window
    if not win:
        return None, None, None

    for area in win.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            if not space or space.type != 'VIEW_3D':
                continue
            region = None
            for reg in area.regions:
                if reg.type == 'WINDOW':
                    region = reg
                    break
            if region:
                return area, space, region
    return None, None, None


def ensure_camera_collection(scene):
    root = scene.collection
    coll = root.children.get("Cameras")
    if coll is None:
        coll = bpy.data.collections.new("Cameras")
        root.children.link(coll)
    return coll


def get_target_camera(context):
    """Prefer active object if it's a camera; else scene camera."""
    obj = context.view_layer.objects.active
    if obj and obj.type == 'CAMERA':
        return obj
    cam = context.scene.camera
    if cam and cam.type == 'CAMERA':
        return cam
    return None


# ------------------------------------------------------------------------
# Per-scene + per-object properties
# ------------------------------------------------------------------------

def update_camera_index(self, context):
    
    if context is None:
        return

    scene = context.scene
    if not scene or not hasattr(scene, "camtools"):
        return

    camtools = scene.camtools
    idx = camtools.camera_index

    objs = scene.objects
    if idx < 0 or idx >= len(objs):
        return

    obj = objs[idx]
    if obj.type != 'CAMERA':
        return

    view_layer = context.view_layer
    if not view_layer:
        return

    # Selecting via UI list should select the camera in the scene
   
    for o in list(view_layer.objects):
        if o.select_get():
            o.select_set(False)

    obj.select_set(True)
    view_layer.objects.active = obj


class CamToolsSceneProps(PropertyGroup):
    camera_index: IntProperty(
        name="Camera Index",
        description="Active camera index in the camera list",
        default=0,
        min=0,
        update=update_camera_index,
    )

    show_composition_guides: BoolProperty(
        name="Composition Guides",
        description="Show composition guide options",
        default=True,
    )

    show_dof: BoolProperty(
        name="Depth of Field",
        description="Show Depth of Field options",
        default=False,  # closed by default
    )

    show_viewport_display: BoolProperty(
        name="Viewport Display",
        description="Show Viewport Display options",
        default=False,  # closed by default
    )


class CamToolsObjectProps(PropertyGroup):
    selected_for_ops: BoolProperty(
        name="Batch Select",
        description="Include this camera in batch operations (Delete, etc.)",
        default=False,
    )


# ------------------------------------------------------------------------
# Depsgraph handler: sync list from active camera
# ------------------------------------------------------------------------

@persistent
def camtools_sync_active(depsgraph):
    global _is_syncing_camtools

    # Re-entrancy guard: don't let other depsgraph changes re-trigger us mid-update
    if _is_syncing_camtools:
        return

    context = bpy.context
    if not context:
        return

    # Skip when no window / viewport (background render, command-line ops, etc.)
    if not context.window or not context.view_layer:
        return

    scene = context.scene
    if not scene or not hasattr(scene, "camtools"):
        return

    active = context.view_layer.objects.active
    if not active or active.type != 'CAMERA':
        return

    idx = scene.objects.find(active.name)
    if idx == -1:
        return

    # No change needed – avoid triggering the property update callback unnecessarily
    if scene.camtools.camera_index == idx:
        return

    _is_syncing_camtools = True
    try:
        # This will call update_camera_index, which does the selection sync
        scene.camtools.camera_index = idx
    finally:
        _is_syncing_camtools = False


# ------------------------------------------------------------------------
# UI List
# ------------------------------------------------------------------------

class CAMTOOLS_UL_cameras(UIList):
    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        flags = [0] * len(items)
        indices = list(range(len(items)))

        bitflag = self.bitflag_filter_item
        for i, obj in enumerate(items):
            if getattr(obj, "type", "") == 'CAMERA':
                flags[i] = bitflag

        return flags, indices

    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        obj = item
        if obj.type != 'CAMERA':
            return

        scene = context.scene
        row = layout.row(align=True)

        # Icon = "set active & view" button
        icon_cam = 'CAMERA_DATA'
        if scene.camera == obj:
            icon_cam = 'OUTLINER_OB_CAMERA'

        op = row.operator("camtools.activate_camera", text="", icon=icon_cam)
        op.camera_name = obj.name

        # Name
        row.prop(obj, "name", text="", emboss=False)

        # Render toggle
        row.prop(obj, "hide_render", text="")
        row.separator(factor=1.5)
        # Batch select checkbox
        row.prop(obj.camtools, "selected_for_ops", text="")


# ------------------------------------------------------------------------
# Operators – Camera creation, activation, duplicate, delete
# ------------------------------------------------------------------------

class VIEW3D_OT_add_camera_from_view_exact(Operator):
    bl_idname = "view3d.add_camera_from_view_exact"
    bl_label = "Add Camera From View"
    bl_description = (
        "Add a camera that matches the current viewport framing "
        "and stores it in 'Cameras' collection"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        area, space, region = get_view3d_area_space(context)
        if not area or not space or not region:
            self.report({'ERROR'}, "No 3D Viewport found")
            return {'CANCELLED'}

        if space.type != 'VIEW_3D':
            self.report({'ERROR'}, "Active space is not a 3D View")
            return {'CANCELLED'}

        r3d = space.region_3d
        scene = context.scene

        # viewport lens / 2 in perspective,
        # or copy lens if already in camera view.
        new_cam_focal = space.lens / 2.0

        if scene.camera and scene.camera.type == 'CAMERA' and r3d.view_perspective == 'CAMERA':
            if getattr(space, "use_local_camera", False) and space.camera and space.camera.type == 'CAMERA':
                new_cam_focal = space.camera.data.lens
            else:
                new_cam_focal = scene.camera.data.lens

        # Ensure Object mode
        obj = context.active_object
        if obj and obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Add camera
        bpy.ops.object.camera_add()
        cam_obj = context.active_object
        cam_data = cam_obj.data

        # Move it into 'Cameras' collection
        cam_coll = ensure_camera_collection(scene)

        for c in list(cam_obj.users_collection):
            try:
                c.objects.unlink(cam_obj)
            except RuntimeError:
                pass

        if cam_obj.name not in cam_coll.objects:
            cam_coll.objects.link(cam_obj)

        # Match viewport transform
        cam_obj.matrix_world = r3d.view_matrix.inverted()

        # Apply focal
        cam_data.lens = new_cam_focal

        # Make it the scene camera and view through it
        scene.camera = cam_obj
        r3d.view_perspective = 'CAMERA'
        space.camera = cam_obj

        for o in context.selected_objects:
            o.select_set(False)
        cam_obj.select_set(True)
        context.view_layer.objects.active = cam_obj

        return {'FINISHED'}


class CAMTOOLS_OT_activate_camera(Operator):
    bl_idname = "camtools.activate_camera"
    bl_label = "Set Active & View Camera"
    bl_description = "Set this camera as the scene camera, select it, and look through it"
    bl_options = {'REGISTER', 'UNDO'}

    camera_name: StringProperty()

    def execute(self, context):
        cam = bpy.data.objects.get(self.camera_name)
        if not cam or cam.type != 'CAMERA':
            self.report({'WARNING'}, "Camera not found")
            return {'CANCELLED'}

        scene = context.scene
        scene.camera = cam

        for o in context.selected_objects:
            o.select_set(False)
        cam.select_set(True)
        context.view_layer.objects.active = cam

        area, space, region = get_view3d_area_space(context)
        if area and space and region:
            r3d = space.region_3d
            r3d.view_perspective = 'CAMERA'
            space.camera = cam

        return {'FINISHED'}


class CAMTOOLS_OT_duplicate_selected_camera(Operator):
    bl_idname = "camtools.duplicate_selected_camera"
    bl_label = "Duplicate Selected Camera"
    bl_description = "Duplicate the active camera and add the copy to the 'Cameras' collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        active = context.view_layer.objects.active

        if not active or active.type != 'CAMERA':
            self.report({'WARNING'}, "Active object is not a camera")
            return {'CANCELLED'}

        cam_coll = ensure_camera_collection(scene)

        new_obj = active.copy()
        new_obj.data = active.data.copy()
        new_obj.animation_data_clear()
        new_obj.name = active.name + "_copy"

        cam_coll.objects.link(new_obj)

        for o in context.selected_objects:
            o.select_set(False)
        new_obj.select_set(True)
        context.view_layer.objects.active = new_obj

        scene.camera = new_obj

        return {'FINISHED'}


class CAMTOOLS_OT_delete_cameras(Operator):
    bl_idname = "camtools.delete_cameras"
    bl_label = "Delete Camera(s)"
    bl_description = (
        "Delete all cameras checked in the list; "
        "if none are checked, delete the active camera"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene

        cams_marked = [
            obj for obj in scene.objects
            if obj.type == 'CAMERA'
            and hasattr(obj, "camtools")
            and obj.camtools.selected_for_ops
        ]

        cams_to_delete = list(cams_marked)

        if not cams_to_delete:
            active = context.view_layer.objects.active
            if not active or active.type != 'CAMERA':
                self.report({'WARNING'}, "No cameras marked and active object is not a camera")
                return {'CANCELLED'}
            cams_to_delete = [active]

        cam_names = [cam.name for cam in cams_to_delete]

        for name in cam_names:
            cam_obj = bpy.data.objects.get(name)
            if cam_obj is None:
                continue

            if scene.camera == cam_obj:
                scene.camera = None

            bpy.data.objects.remove(cam_obj, do_unlink=True)

        if scene.camera is None:
            for obj in scene.objects:
                if obj.type == 'CAMERA':
                    scene.camera = obj
                    break

        for obj in scene.objects:
            if obj.type == 'CAMERA' and hasattr(obj, "camtools"):
                obj.camtools.selected_for_ops = False

        return {'FINISHED'}


# ------------------------------------------------------------------------
# Operators – Mirror & Level Verticals
# ------------------------------------------------------------------------

class CAMTOOLS_OT_mirror_camera_local_x(Operator):
    bl_idname = "camtools.mirror_camera_local_x"
    bl_label = "Mirror X (Local)"
    bl_description = "Mirror the active camera across its local X axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cam_obj = get_target_camera(context)
        if not cam_obj:
            self.report({'WARNING'}, "No active camera to mirror")
            return {'CANCELLED'}

        Sx = mathutils.Matrix.Scale(-1.0, 4, (1, 0, 0))
        cam_obj.matrix_world = cam_obj.matrix_world @ Sx

        return {'FINISHED'}


class CAMTOOLS_OT_mirror_camera_local_y(Operator):
    bl_idname = "camtools.mirror_camera_local_y"
    bl_label = "Mirror Y (Local)"
    bl_description = "Mirror the active camera across its local Y axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cam_obj = get_target_camera(context)
        if not cam_obj:
            self.report({'WARNING'}, "No active camera to mirror")
            return {'CANCELLED'}

        Sy = mathutils.Matrix.Scale(-1.0, 4, (0, 1, 0))
        cam_obj.matrix_world = cam_obj.matrix_world @ Sy

        return {'FINISHED'}


class CAMTOOLS_OT_auto_level_verticals(Operator):
    bl_idname = "camtools.auto_level_verticals"
    bl_label = "Level Verticals"
    bl_description = (
        "Make verticals straight and keep the current framing using lens shift."
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cam_obj = get_target_camera(context)
        if not cam_obj:
            self.report({'WARNING'}, "No active camera to level")
            return {'CANCELLED'}

        scene = context.scene
        render = scene.render
        depsgraph = context.evaluated_depsgraph_get()

        mw = cam_obj.matrix_world
        R = mw.to_3x3()
        up_world = R.col[1]
        world_up = mathutils.Vector((0.0, 0.0, 1.0))

        # Early exit if already level (idempotent behavior)
        if up_world.cross(world_up).length < 1e-4:
            return {'FINISHED'}

        # 1) Find a target point along the current center ray
        ray_origin = cam_obj.location.copy()
        cam_rot_q = mw.to_quaternion()
        forward_pre = (cam_rot_q @ mathutils.Vector((0.0, 0.0, -1.0))).normalized()

        hit, hit_loc, _, _, _, _ = scene.ray_cast(depsgraph, ray_origin, forward_pre)
        if hit:
            target = hit_loc
        else:
            dist = cam_obj.data.dof.focus_distance or 10.0
            target = ray_origin + forward_pre * dist

        # 2) Level the camera so verticals are parallel
        loc, rot_q, scale_v = mw.decompose()
        forward = -R.col[2]

        forward_h = mathutils.Vector((forward.x, forward.y, 0.0))
        if forward_h.length < 1e-6:
            self.report({'WARNING'}, "Camera pointing straight up/down; cannot auto level robustly")
            return {'CANCELLED'}
        forward_h.normalize()

        new_forward = forward_h
        new_right = new_forward.cross(world_up)
        if new_right.length < 1e-6:
            self.report({'WARNING'}, "Degenerate orientation for auto level")
            return {'CANCELLED'}
        new_right.normalize()
        new_up = world_up

        new_R = mathutils.Matrix((new_right, new_up, -new_forward)).transposed()
        new_mw = mathutils.Matrix.LocRotScale(loc, new_R.to_quaternion(), scale_v)
        cam_obj.matrix_world = new_mw

        depsgraph.update()

        # 3) Compute shift_y to keep the target at frame center
        cam_data = cam_obj.data
        cam_data.shift_y = 0.0

        target_ndc = bpy_extras.object_utils.world_to_camera_view(
            scene,
            cam_obj,
            target,
        )

        shift_y = target_ndc.y - 0.5

        aspect_ratio = (
            render.resolution_x / render.resolution_y
            * render.pixel_aspect_x / render.pixel_aspect_y
        )
        if cam_data.sensor_fit == 'HORIZONTAL' or (
            cam_data.sensor_fit == 'AUTO' and aspect_ratio > 1
        ):
            shift_y /= aspect_ratio

        cam_data.shift_y = shift_y
        depsgraph.update()

        return {'FINISHED'}
# ------------------------------------------------------------------------
# Panel helpers
# ------------------------------------------------------------------------

def draw_camtools(layout, context):
    """Shared UI for Cam Tools, reusable from any panel."""
    scene = context.scene
    camtools = scene.camtools

    layout.operator("view3d.add_camera_from_view_exact", icon='CAMERA_DATA')

    layout.separator()

    layout.label(text="Cameras:")
    layout.template_list(
        "CAMTOOLS_UL_cameras",
        "",
        scene,
        "objects",
        camtools,
        "camera_index",
        rows=5,
    )

    # breathing space between list and buttons
    layout.separator(factor=0.5)

    row = layout.row(align=True)
    row.operator("camtools.duplicate_selected_camera", text="Duplicate", icon='DUPLICATE')
    row.operator("camtools.delete_cameras", text="Delete", icon='TRASH')

    layout.separator()

    cam_obj = get_target_camera(context)
    if not cam_obj:
        layout.label(text="No active camera", icon='ERROR')
        return

    cam = cam_obj.data

    # --- Camera Controls Box ---
    box = layout.box()
    box.label(text=f"Active: {cam_obj.name}", icon='CAMERA_DATA')

    col = box.column(align=True)
    col.prop(cam, "lens", text="Focal Length")
    col.separator()

    # Shift X / Y
    row = col.row(align=True)
    row.prop(cam, "shift_x", text="Shift X")
    row.prop(cam, "shift_y", text="Shift Y")

    # A bit of breathing space before Level Verticals
    col.separator()
    row = col.row(align=True)
    row.operator("camtools.auto_level_verticals", text="Level Verticals", icon='AXIS_TOP')

    # Smaller space before Mirror controls (tighter grouping)
    col.separator()
    row = box.row(align=True)
    row.label(text="Mirror (Local):")
    row.operator("camtools.mirror_camera_local_x", text="X")
    row.operator("camtools.mirror_camera_local_y", text="Y")

    layout.separator()

    # --- Depth of Field Box (collapsible) ---
    dof = cam.dof
    dof_outer = layout.box()
    header = dof_outer.row(align=True)
    icon = 'TRIA_DOWN' if camtools.show_dof else 'TRIA_RIGHT'
    header.prop(camtools, "show_dof", text="", icon=icon, emboss=False)
    header.label(text="Depth of Field")

    if camtools.show_dof:
        col = dof_outer.column(align=True)

        # Enable toggle (always editable)
        row = col.row(align=True)
        row.prop(dof, "use_dof", text="Enable")

        # Everything below is disabled when DOF is off
        sub = col.column(align=True)
        sub.enabled = dof.use_dof

        sub.prop(dof, "focus_distance", text="Focus Distance")
        sub.separator(factor=0.5)

        row = sub.row(align=True)
        split = row.split(factor=0.35, align=True)
        split.label(text="Focus Object")
        split.prop(dof, "focus_object", text="")

        sub.separator()

        if hasattr(dof, "aperture_fstop"):
            sub.prop(dof, "aperture_fstop", text="Aperture (f-stop)")

    layout.separator()

    # --- Viewport Display Box (collapsible) ---
    vbox_outer = layout.box()
    header = vbox_outer.row(align=True)
    icon = 'TRIA_DOWN' if camtools.show_viewport_display else 'TRIA_RIGHT'
    header.prop(camtools, "show_viewport_display", text="", icon=icon, emboss=False)
    header.label(text="Viewport Display")

    if camtools.show_viewport_display:
        # Passepartout options
        col = vbox_outer.column(align=True)
        col.label(text="Passepartout:")
        col.prop(cam, "show_passepartout", text="Enable")
        col.prop(cam, "passepartout_alpha", text="Opacity")

        vbox_outer.separator()

        # Composition guides (collapsible) inside Viewport Display
        comp_box = vbox_outer.box()
        header = comp_box.row(align=True)
        icon = 'TRIA_DOWN' if camtools.show_composition_guides else 'TRIA_RIGHT'
        header.prop(camtools, "show_composition_guides", text="", icon=icon, emboss=False)
        header.label(text="Composition Guides")

        if camtools.show_composition_guides:
            col = comp_box.column(align=True)

            row = col.row(align=True)
            row.prop(cam, "show_composition_thirds", text="Thirds")
            row.prop(cam, "show_composition_center", text="Center")

            row = col.row(align=True)
            row.prop(cam, "show_composition_center_diagonal", text="Diagonal")
            row.prop(cam, "show_composition_golden", text="Golden")

            row = col.row(align=True)
            row.prop(cam, "show_composition_golden_tria_a", text="Golden Tri A")
            row.prop(cam, "show_composition_golden_tria_b", text="Golden Tri B")

            row = col.row(align=True)
            row.prop(cam, "show_composition_harmony_tri_a", text="Harmony Tri A")
            row.prop(cam, "show_composition_harmony_tri_b", text="Harmony Tri B")

# ------------------------------------------------------------------------
# Panel
# ------------------------------------------------------------------------


class VIEW3D_PT_camera_from_view(Panel):
    bl_label = "Cam Tools"
    bl_idname = "VIEW3D_PT_camera_from_view"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Cam-Tools"

    def draw(self, context):
        draw_camtools(self.layout, context)
    

# ------------------------------------------------------------------------
# Registration
# ------------------------------------------------------------------------

classes = (
    CamToolsSceneProps,
    CamToolsObjectProps,
    CAMTOOLS_UL_cameras,
    VIEW3D_OT_add_camera_from_view_exact,
    CAMTOOLS_OT_activate_camera,
    CAMTOOLS_OT_duplicate_selected_camera,
    CAMTOOLS_OT_delete_cameras,
    CAMTOOLS_OT_mirror_camera_local_x,
    CAMTOOLS_OT_mirror_camera_local_y,
    CAMTOOLS_OT_auto_level_verticals,
    # VIEW3D_PT_camera_from_view, # now drawn via combined panel in ui.py
)


def register_camtools():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.camtools = PointerProperty(type=CamToolsSceneProps)
    bpy.types.Object.camtools = PointerProperty(type=CamToolsObjectProps)

    # Add handler for syncing list selection from active camera
    if camtools_sync_active not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(camtools_sync_active)


def unregister_camtools():
    # Remove handler
    if camtools_sync_active in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(camtools_sync_active)

    del bpy.types.Scene.camtools
    del bpy.types.Object.camtools

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)    


